//
//  GolfCourse.swift
//  Aldo
//
//  Created by Andrew Katsifis on 1/26/25.
//

import Foundation

struct GolfCourse: Identifiable {
    let id: Int
    let name: String
    let par: Int
}
