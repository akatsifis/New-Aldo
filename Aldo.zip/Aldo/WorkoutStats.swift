//
//  WorkoutStats.swift
//  Aldo
//
//  Created by Andrew Katsifis on 6/25/24.
//


import Foundation

struct WorkoutStats {
    var steps: Int
    var distance: Double
    var caloriesBurned: Double
}
